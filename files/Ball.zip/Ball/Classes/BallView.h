//
//  BallView.h
//  Ball
//
//  Created by Owen Yamauchi on 3/31/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface BallView : UIView <UIAccelerometerDelegate> {
  CGPoint ballPosition;
}

@end
