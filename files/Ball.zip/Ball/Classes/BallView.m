//
//  BallView.m
//  Ball
//
//  Created by Owen Yamauchi on 3/31/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BallView.h"

#define kBALL_RADIUS 20.0


@implementation BallView


- (id)initWithFrame:(CGRect)frame {
  if (self = [super initWithFrame:frame]) {
    ballPosition = CGPointMake(self.bounds.size.width / 2,
                               self.bounds.size.height / 2);
  }
  return self;
}


- (void)drawRect:(CGRect)rect {
  CGContextRef context = UIGraphicsGetCurrentContext();
  CGContextSetRGBFillColor(context, 1.0, 1.0, 1.0, 1.0);
  CGContextFillRect(context, self.bounds);
  CGContextSetRGBFillColor(context, 0.0, 0.0, 0.0, 1.0);
  
  CGRect circleRect = CGRectMake(ballPosition.x - kBALL_RADIUS,
                                 ballPosition.y - kBALL_RADIUS,
                                 kBALL_RADIUS * 2.0,
                                 kBALL_RADIUS * 2.0);
  CGContextFillEllipseInRect(context, circleRect);
}

- (void)dealloc {
  [super dealloc];
}


@end
