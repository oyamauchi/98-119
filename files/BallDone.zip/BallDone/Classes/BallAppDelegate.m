//
//  BallAppDelegate.m
//  Ball
//
//  Created by Owen Yamauchi on 3/31/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "BallAppDelegate.h"
#import "BallView.h"

@implementation BallAppDelegate

@synthesize window;


- (void)applicationDidFinishLaunching:(UIApplication *)application {
  CGRect frame = [window bounds];
  float statusBarHeight = [[UIApplication sharedApplication] statusBarFrame].size.height;
  frame.origin.y += statusBarHeight;
  frame.size.height -= statusBarHeight;

  BallView *view = [[BallView alloc] initWithFrame:frame];
  [window addSubview:view];
  [window makeKeyAndVisible];
}


- (void)dealloc {
    [window release];
    [super dealloc];
}


@end
