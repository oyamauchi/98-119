//
//  ClickCountAppDelegate.h
//  ClickCount
//
//  Created by Owen Yamauchi on 1/13/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ClickCountAppDelegate : NSObject <UIApplicationDelegate> {
  UIWindow *window;
  UILabel *label;
  
  int clickCount;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UILabel *label;

- (IBAction)buttonPressed:(id)sender;

@end

