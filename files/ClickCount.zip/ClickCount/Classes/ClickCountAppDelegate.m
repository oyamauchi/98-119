//
//  ClickCountAppDelegate.m
//  ClickCount
//
//  Created by Owen Yamauchi on 1/13/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "ClickCountAppDelegate.h"


@implementation ClickCountAppDelegate

@synthesize window;
@synthesize label;

- (void)applicationDidFinishLaunching:(UIApplication *)application {    
  clickCount = 0;
  label.text = [NSString stringWithFormat:@"%i", clickCount];
  
  // Override point for customization after application launch
  [window makeKeyAndVisible];
  // Equivalent in Java to: window.makeKeyAndVisible();
}


- (IBAction)buttonPressed:(id)sender {
  clickCount++;
  
  // Note that this syntax for setting the label's text is exactly
  // equivalent to that on line 19 (they get compiled to exactly
  // the same thing). I included both for demonstration.
  [label setText:[NSString stringWithFormat:@"%i", clickCount]];
}


- (void)dealloc {
  [window release];
  [label release];
  [super dealloc];
}


@end
