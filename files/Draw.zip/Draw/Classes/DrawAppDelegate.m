//
//  DrawAppDelegate.m
//  Draw
//
//  Created by Owen Yamauchi on 2/24/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "DrawAppDelegate.h"
#import "DrawView.h"

@implementation DrawAppDelegate

@synthesize window;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
  DrawView *view = [[DrawView alloc] initWithFrame:[window bounds]];
  [window addSubview:view];
  [view release];

    // Override point for customization after application launch
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [window release];
    [super dealloc];
}


@end
