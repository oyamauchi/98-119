//
//  DrawView.h
//  Draw
//
//  Created by Owen Yamauchi on 2/24/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface DrawView : UIView {
  CGMutablePathRef currentPath;
}

@end
