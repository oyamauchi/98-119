//
//  DrawView.m
//  Draw
//
//  Created by Owen Yamauchi on 2/24/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "DrawView.h"


@implementation DrawView


- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
      currentPath = CGPathCreateMutable();
    }
    return self;
}


- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
  UITouch *t = [touches anyObject];
  CGPoint location = [t locationInView:self];
  CGPathMoveToPoint(currentPath, NULL, location.x, location.y);
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
  UITouch *t = [touches anyObject];
  CGPoint location = [t locationInView:self];
  CGPathAddLineToPoint(currentPath, NULL, location.x, location.y);
  [self setNeedsDisplay];
}

- (void)drawRect:(CGRect)rect {
  float white[] = {1.0, 1.0, 1.0, 1.0};
  CGContextRef context = UIGraphicsGetCurrentContext();
  CGContextSetFillColor(context, white);
  CGContextFillRect(context, [self bounds]);

  float red[] = {1.0, 0.0, 0.0, 1.0};
  CGContextSetStrokeColor(context, red);
  CGContextSetLineWidth(context, 12.0);
  CGContextAddPath(context, currentPath);
  CGContextStrokePath(context);
}


- (void)dealloc {
  CGPathRelease(currentPath);
  [super dealloc];
}


@end
