//
//  LocalizeMeAppDelegate.h
//  LocalizeMe
//
//  Created by Owen Yamauchi on 3/3/09.
//  Copyright Owen Yamauchi 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LocalizeMeAppDelegate : NSObject <UIApplicationDelegate> {
	IBOutlet UIWindow *window;
	IBOutlet UIDatePicker *datePicker;
	IBOutlet UILabel *outputLabel;

	NSDateFormatter *formatter;
}

- (IBAction)calculate:(id)sender;

@end

