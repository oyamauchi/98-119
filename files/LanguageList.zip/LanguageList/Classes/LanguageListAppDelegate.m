//
//  LanguageListAppDelegate.m
//  LanguageList
//
//  Created by Owen Yamauchi on 2/17/09.
//  Copyright Owen Yamauchi 2009. All rights reserved.
//

#import "LanguageListAppDelegate.h"
#import "ListController.h"

@implementation LanguageListAppDelegate

@synthesize window;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
	ListController *lc = [[ListController alloc] initWithStyle:UITableViewStyleGrouped];
	nc = [[UINavigationController alloc] initWithRootViewController:lc];
	[lc release];
	[window addSubview:[nc view]];
	[window makeKeyAndVisible];
}


- (void)dealloc {
	[window release];
	[nc release];
	[super dealloc];
}


@end
