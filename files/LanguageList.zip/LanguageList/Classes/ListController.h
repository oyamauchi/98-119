//
//  ListController.h
//  LanguageList
//
//  Created by Owen Yamauchi on 2/17/09.
//  Copyright 2009 Owen Yamauchi. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ListController : UITableViewController {
	NSMutableArray *englishNames;
	NSMutableArray *nativeNames;
}

@end
