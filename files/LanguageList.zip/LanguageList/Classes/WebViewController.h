//
//  WebViewController.h
//  LanguageList
//
//  Created by Owen Yamauchi on 2/17/09.
//  Copyright 2009 Owen Yamauchi. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface WebViewController : UIViewController <UIWebViewDelegate> {
	NSString *languageName;
	UIWebView *webView;
	UIActivityIndicatorView *spinner;
}
- (id)initWithLanguageName:(NSString *)name;
@end
