//
//  ListController.m
//  LanguageList
//
//  Created by Owen Yamauchi on 2/17/09.
//  Copyright 2009 Owen Yamauchi. All rights reserved.
//

#import "ListController.h"
#import "WebViewController.h"

@implementation ListController


- (id)initWithStyle:(UITableViewStyle)style {
	if (self = [super initWithStyle:style]) {
		englishNames = [[NSMutableArray alloc] initWithObjects:@"Afrikaans", @"Danish",
			@"Dutch", @"English", @"Faeroese", @"Frisian", @"German", @"Icelandic",
			@"Norwegian", @"Swedish", @"Yiddish", nil];
		nativeNames = [[NSMutableArray alloc] initWithObjects:@"Afrikaans", @"Dansk",
			@"Nederlands", @"English", @"føroyskt", @"Frysk", @"Deutsch", @"íslenska",
			@"Norsk", @"Svenska", @"yidish", nil];
		self.title = @"Germanic languages";

		UIBarButtonItem *backItem = [[UIBarButtonItem alloc] initWithTitle:@"Germanic"
																																 style:UIBarButtonItemStyleBordered
																																target:nil
																																action:nil];
		self.navigationItem.backBarButtonItem = backItem;
		[backItem release];
	}
	return self;
}


// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	// Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	return 1;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	// Hopefully [englishNames count] and [nativeNames count] are the same
	return [englishNames count];
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	static NSString *CellIdentifier = @"Cell";
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
		cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	}
	
	NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
	BOOL useEnglish = [ud boolForKey:@"english_preference"];
	if (useEnglish) {
		cell.text = [englishNames objectAtIndex:indexPath.row];
	} else {
		cell.text = [nativeNames objectAtIndex:indexPath.row];
	}

	return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	NSString *language = [englishNames objectAtIndex:indexPath.row];
	WebViewController *wvc = [[WebViewController alloc] initWithLanguageName:language];
	[self.navigationController pushViewController:wvc animated:YES];
	[wvc release];
}


- (void)dealloc {
	[englishNames release];
	[nativeNames release];
	[super dealloc];
}


@end

