//
//  GridView.m
//  LetterGrid
//
//  Created by Owen Yamauchi on 3/19/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "GridView.h"


@implementation GridView


- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        // Initialization code
    }
    return self;
}


- (void)drawRect:(CGRect)rect {
  CGContextRef context = UIGraphicsGetCurrentContext();
  CGContextSetRGBFillColor(context, 1.0, 1.0, 1.0, 1.0);
  CGContextFillRect(context, [self bounds]);
  
  CGContextSetRGBFillColor(context, 0.0, 0.0, 0.0, 1.0);
  NSString *string = @"Not a grid, but oh well";
  [string drawAtPoint:CGPointMake(100, 100)
             withFont:[UIFont systemFontOfSize:[UIFont systemFontSize]]];
}


- (void)dealloc {
    [super dealloc];
}


@end
