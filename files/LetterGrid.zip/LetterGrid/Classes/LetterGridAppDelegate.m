//
//  LetterGridAppDelegate.m
//  LetterGrid
//
//  Created by Owen Yamauchi on 3/19/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "LetterGridAppDelegate.h"
#import "GridView.h"

@implementation LetterGridAppDelegate

@synthesize window;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
  GridView *grid = [[GridView alloc] initWithFrame:[window bounds]];
  [window addSubview:grid];
  [grid release];
  [window makeKeyAndVisible];
}


- (void)dealloc {
  [window release];
  [super dealloc];
}


@end
