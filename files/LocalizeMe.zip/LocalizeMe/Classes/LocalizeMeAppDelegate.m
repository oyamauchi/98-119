//
//  LocalizeMeAppDelegate.m
//  LocalizeMe
//
//  Created by Owen Yamauchi on 3/3/09.
//  Copyright Owen Yamauchi 2009. All rights reserved.
//

#import "LocalizeMeAppDelegate.h"

@implementation LocalizeMeAppDelegate


- (void)applicationDidFinishLaunching:(UIApplication *)application {
	formatter = [[NSDateFormatter alloc] init];
	[formatter setDateFormat:@"EEEE"];

	[datePicker setDate:[NSDate date] animated:NO];
	[self calculate:self];
	[window makeKeyAndVisible];
}

- (IBAction)calculate:(id)sender
{
	NSString *answer = [formatter stringFromDate:[datePicker date]];
	[outputLabel setText:[NSString stringWithFormat:@"You were born on a %@.", answer]];
}

- (void)dealloc {
	[window release];
	[datePicker release];
	[outputLabel release];
	[formatter release];
	[super dealloc];
}


@end
