//
//  InfoViewController.m
//  Locate
//
//  Created by Owen Yamauchi on 4/7/09.
//  Copyright 2009 Owen Yamauchi. All rights reserved.
//

#import "InfoViewController.h"
#import "TitleDetailCell.h"

#define kLatitudeKey @"latitude"
#define kLongitudeKey @"longitude"
#define kAltitudeKey @"altitude"
#define kAccuracyKey @"accuracy"
#define kSpeedKey @"speed"
#define kCourseKey @"course"

#define kDataSection 0
#define kButtonSection 1

#define kMapsURLFormat @"http://maps.google.com/maps?ll=%@,%@"

@implementation InfoViewController

- (id)init {
    // Override initWithStyle: if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
    if (self = [super initWithStyle:UITableViewStyleGrouped]) {
			data = [[NSMutableDictionary alloc] init];
			
			/* set up location */
    }
    return self;
}

- (void)dealloc {
	[data release];
	[super dealloc];
}


#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	return 2;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return (section == kDataSection ? 6 : 1);
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	NSString *CellIdentifier = (indexPath.section == kDataSection ? @"Detail" : @"Normal");
	
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (cell == nil) {
		if (indexPath.section == kDataSection) {
			cell = [[[TitleDetailCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
		} else {
			cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
			cell.textAlignment = UITextAlignmentCenter;
		}
	}
	
	if (indexPath.section == kDataSection) {
		TitleDetailCell *tdc = (TitleDetailCell *)cell;
		if (indexPath.row == 0) {
			[tdc setTitle:@"Latitude"];
			[tdc setDetail:[data objectForKey:kLatitudeKey]];
		} else if (indexPath.row == 1) {
			[tdc setTitle:@"Longitude"];
			[tdc setDetail:[data objectForKey:kLongitudeKey]];
		} else if (indexPath.row == 2) {
			[tdc setTitle:@"Altitude"];
			[tdc setDetail:[data objectForKey:kAltitudeKey]];
		} else if (indexPath.row == 3) {
			[tdc setTitle:@"Accuracy"];
			[tdc setDetail:[data objectForKey:kAccuracyKey]];
		} else if (indexPath.row == 4) {
			[tdc setTitle:@"Speed"];
			[tdc setDetail:[data objectForKey:kSpeedKey]];
		} else if (indexPath.row == 5) {
			[tdc setTitle:@"Course"];
			[tdc setDetail:[data objectForKey:kCourseKey]];
		}
	} else {
		cell.text = @"Open in Maps";
	}

	return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	if (indexPath.section == kButtonSection) {
		NSString *latitude = [data objectForKey:kLatitudeKey];
		NSString *longitude = [data objectForKey:kLongitudeKey];
		NSString *link = [NSString stringWithFormat:kMapsURLFormat, latitude, longitude];
		[tableView deselectRowAtIndexPath:indexPath animated:YES];
		[[UIApplication sharedApplication] openURL:[NSURL URLWithString:link]];
	} else {
		[tableView deselectRowAtIndexPath:indexPath animated:NO];
	}
}

@end

