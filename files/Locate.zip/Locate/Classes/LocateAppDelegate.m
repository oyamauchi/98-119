//
//  LocateAppDelegate.m
//  Locate
//
//  Created by Owen Yamauchi on 4/7/09.
//  Copyright Owen Yamauchi 2009. All rights reserved.
//

#import "LocateAppDelegate.h"

@implementation LocateAppDelegate

@synthesize window;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
	controller = [[InfoViewController alloc] init];
	[window addSubview:[controller view]];
	[window makeKeyAndVisible];
}


- (void)dealloc {
	[window release];
	[controller release];
	[super dealloc];
}


@end
