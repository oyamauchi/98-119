//
//  TitleDetailCell.h
//  SpeakersList
//
//  Created by Owen Yamauchi on 3/17/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface TitleDetailCell : UITableViewCell {
  UILabel *titleLabel;
  UILabel *detailLabel;
}

- (void)setTitle:(NSString *)title;
- (void)setDetail:(NSString *)detail;

@end
