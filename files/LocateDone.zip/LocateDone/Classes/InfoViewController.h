//
//  InfoViewController.h
//  Locate
//
//  Created by Owen Yamauchi on 4/7/09.
//  Copyright 2009 Owen Yamauchi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface InfoViewController : UITableViewController <CLLocationManagerDelegate> {
	NSMutableDictionary *data;
	CLLocationManager *locationManager;
}

@end
