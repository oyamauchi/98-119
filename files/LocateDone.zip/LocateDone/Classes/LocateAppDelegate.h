//
//  LocateAppDelegate.h
//  Locate
//
//  Created by Owen Yamauchi on 4/7/09.
//  Copyright Owen Yamauchi 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "InfoViewController.h"

@interface LocateAppDelegate : NSObject <UIApplicationDelegate> {
	UIWindow *window;
	InfoViewController *controller;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

