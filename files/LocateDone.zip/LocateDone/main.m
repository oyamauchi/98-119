//
//  main.m
//  Locate
//
//  Created by Owen Yamauchi on 4/7/09.
//  Copyright Owen Yamauchi 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
