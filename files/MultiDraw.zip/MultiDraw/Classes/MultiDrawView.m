//
//  MultiDrawView.m
//  MultiDraw
//
//  Created by Owen Yamauchi on 3/24/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "MultiDrawView.h"


@implementation MultiDrawView


- (id)initWithFrame:(CGRect)frame {
  if (self = [super initWithFrame:frame]) {
    
    // Fill in
    
  }
  return self;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{

}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{

}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{

}


- (void)drawRect:(CGRect)rect {
  CGContextRef context = UIGraphicsGetCurrentContext();


}


- (void)dealloc {
  // Fill in
  [super dealloc];
}


@end
