//
//  WordListController.h
//  QuickWordList
//
//  Created by Owen Yamauchi on 2/3/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface WordListController : UITableViewController {
  NSMutableArray *wordList;
}

@end
