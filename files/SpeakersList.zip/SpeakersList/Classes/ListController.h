//
//  ListController.h
//  SpeakersList
//
//  Created by Owen Yamauchi on 3/17/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ListController : UITableViewController {
  NSMutableArray *languages;
  NSMutableArray *speakerCounts;
}

@end
