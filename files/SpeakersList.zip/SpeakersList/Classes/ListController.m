//
//  ListController.m
//  SpeakersList
//
//  Created by Owen Yamauchi on 3/17/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "ListController.h"


@implementation ListController

- (id)initWithStyle:(UITableViewStyle)style {
  if (self = [super initWithStyle:style]) {
    languages = [[NSMutableArray alloc] init];
    speakerCounts = [[NSMutableArray alloc] init];
    
    /* fill them in */
  }
  return self;
}

#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [languages count];
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
  static NSString *CellIdentifier = @"Cell";

  UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
  if (cell == nil) {
      cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
  }

  cell.text = [languages objectAtIndex:indexPath.row];

  return cell;
}


- (void)dealloc {
  [languages release];
  [speakerCounts release];
  [super dealloc];
}


@end

