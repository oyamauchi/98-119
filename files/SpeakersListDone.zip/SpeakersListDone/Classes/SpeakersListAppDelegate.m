//
//  SpeakersListAppDelegate.m
//  SpeakersList
//
//  Created by Owen Yamauchi on 3/17/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "SpeakersListAppDelegate.h"

@implementation SpeakersListAppDelegate


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
  controller = [[ListController alloc] initWithStyle:UITableViewStyleGrouped];
  [window addSubview:[controller view]];
  [window makeKeyAndVisible];
}


- (void)dealloc {
  [window release];
  [controller release];
  [super dealloc];
}


@end
