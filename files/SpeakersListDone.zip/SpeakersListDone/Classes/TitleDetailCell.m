//
//  TitleDetailCell.m
//  SpeakersList
//
//  Created by Owen Yamauchi on 3/17/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "TitleDetailCell.h"


@implementation TitleDetailCell

- (id)initWithFrame:(CGRect)frame reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithFrame:frame reuseIdentifier:reuseIdentifier]) {
      titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
      titleLabel.font = [UIFont boldSystemFontOfSize:[UIFont labelFontSize]];
      titleLabel.backgroundColor = [UIColor clearColor];

      detailLabel = [[UILabel alloc] initWithFrame:CGRectZero];
      detailLabel.font = [UIFont systemFontOfSize:[UIFont systemFontSize]];
      detailLabel.textAlignment = UITextAlignmentRight;
      detailLabel.textColor = [UIColor colorWithRed:0.2 green:0.3 blue:0.5 alpha:1.0];
      detailLabel.backgroundColor = [UIColor clearColor];
      
      [[self contentView] addSubview:titleLabel];
      [[self contentView] addSubview:detailLabel];
    }
    return self;
}

- (UILabel *)titleLabel
{
  return titleLabel;
}

- (UILabel *)detailLabel
{
  return detailLabel;
}

- (void)layoutSubviews
{
  CGRect rect = self.contentView.bounds;
  rect.origin.x += 20;
  rect.size.width -= 40;
  titleLabel.frame = rect;
  detailLabel.frame = rect;
}

- (void)dealloc {
  [titleLabel release];
  [detailLabel release];
  [super dealloc];
}


@end
