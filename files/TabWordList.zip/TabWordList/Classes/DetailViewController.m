//
//  DetailViewController.m
//  QuickWordList
//
//  Created by Owen Yamauchi on 2/10/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "DetailViewController.h"


@implementation DetailViewController


// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil
               bundle:(NSBundle *)nibBundleOrNil
            increment:(int)anIncrement
                index:(int)anIndex
{
  if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
    increment = anIncrement;
    index = anIndex;
  }
  return self;
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
  [super viewDidLoad];
  
  NSString *multiply = [NSString stringWithFormat:@"%i × %i =", increment, index];
  NSString *product = [NSString stringWithFormat:@"%i", increment * index];
  [productLabel setText:product];
  [multiplyLabel setText:multiply];
}

- (void)dealloc {
  [productLabel release];
  [multiplyLabel release];
  [super dealloc];
}


@end
