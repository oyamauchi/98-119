//
//  QuickWordListAppDelegate.m
//  QuickWordList
//
//  Created by Owen Yamauchi on 2/3/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "QuickWordListAppDelegate.h"
#import "WordListController.h"


@implementation QuickWordListAppDelegate

@synthesize window;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
  WordListController *wlc = [[WordListController alloc] initWithStyle:UITableViewStyleGrouped
                                                            increment:10];
  nc = [[UINavigationController alloc] initWithRootViewController:wlc];
  
  [window addSubview:[nc view]];
  [wlc release];
  [window makeKeyAndVisible];
}


- (void)dealloc {
  [window release];
  [nc release];
  [super dealloc];
}


@end
