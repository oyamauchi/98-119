//
//  WordListController.m
//  QuickWordList
//
//  Created by Owen Yamauchi on 2/3/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "WordListController.h"


@implementation WordListController


- (id)initWithStyle:(UITableViewStyle)style increment:(int)anInt {
  if (self = [super initWithStyle:style]) {
    increment = anInt;
    formatter = [[NSNumberFormatter alloc] init];
    [formatter setNumberStyle:NSNumberFormatterSpellOutStyle];
  }
  return self;
}

- (void)viewDidLoad {
  [super viewDidLoad];
  
  NSString *spelledOut = [formatter stringFromNumber:[NSNumber numberWithInt:increment]];
  self.title = [NSString stringWithFormat:@"Increment by %@", spelledOut];
}


#pragma mark Table view methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 20;
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
  NSString *CellIdentifier = @"Cell";

  UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
  if (cell == nil) {
    cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
    /* Make cell look right */
  }

  NSNumber *number = [NSNumber numberWithInt:(indexPath.row * increment)];
  cell.text = [formatter stringFromNumber:number];

  return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
  
  /* Navigation logic */

}


- (void)dealloc {
  [formatter release];
  [super dealloc];
}


@end

