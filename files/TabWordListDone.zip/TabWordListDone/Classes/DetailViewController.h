//
//  DetailViewController.h
//  QuickWordList
//
//  Created by Owen Yamauchi on 2/10/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface DetailViewController : UIViewController {
  IBOutlet UILabel *productLabel;
  IBOutlet UILabel *multiplyLabel;

  int increment;
  int index;
}

- (id)initWithIncrement:(int)anIncrement index:(int)anIndex;

@end
