//
//  DetailViewController.m
//  QuickWordList
//
//  Created by Owen Yamauchi on 2/10/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "DetailViewController.h"


@implementation DetailViewController


// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithIncrement:(int)anIncrement index:(int)anIndex
{
  if (self = [super initWithNibName:@"DetailView" bundle:nil]) {
    increment = anIncrement;
    index = anIndex;
    self.title = @"Multiplication";
  }
  return self;
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
  [super viewDidLoad];

  // Unicode! Note that the argument has no @ and thus is a C string.
  NSString *format = [NSString stringWithUTF8String:"%i \u00d7 %i ="];
  NSString *multiply = [NSString stringWithFormat:format, increment, index];
  NSString *product = [NSString stringWithFormat:@"%i", increment * index];
  [productLabel setText:product];
  [multiplyLabel setText:multiply];
}

- (void)dealloc {
  [productLabel release];
  [multiplyLabel release];
  [super dealloc];
}


@end
