//
//  QuickWordListAppDelegate.m
//  QuickWordList
//
//  Created by Owen Yamauchi on 2/3/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "QuickWordListAppDelegate.h"
#import "WordListController.h"


@implementation QuickWordListAppDelegate

@synthesize window;


- (void)applicationDidFinishLaunching:(UIApplication *)application {
  // I did the array a different way from how I did it in class, to demonstrate
  NSMutableArray *controllers = [[NSMutableArray alloc] init];

  WordListController *wlc;
  UINavigationController *nc;

  tabController = [[UITabBarController alloc] init];

  wlc = [[WordListController alloc] initWithIncrement:2];
  nc = [[UINavigationController alloc] initWithRootViewController:wlc];
  [controllers addObject:nc];
  [wlc release];
  [nc release];
  
  wlc = [[WordListController alloc] initWithIncrement:5];
  nc = [[UINavigationController alloc] initWithRootViewController:wlc];
  [controllers addObject:nc];
  [wlc release];
  [nc release];
  
  tabController.viewControllers = controllers;
  [controllers release];
  
  [window addSubview:[tabController view]];
  [window makeKeyAndVisible];
}


- (void)dealloc {
  [window release];
  [tabController release];
  [super dealloc];
}


@end
