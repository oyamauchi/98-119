//
//  WordListController.m
//  QuickWordList
//
//  Created by Owen Yamauchi on 2/3/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "WordListController.h"
#import "DetailViewController.h"

@implementation WordListController


- (id)initWithIncrement:(int)anInt {
  if (self = [super initWithStyle:UITableViewStyleGrouped]) {
    increment = anInt;
    formatter = [[NSNumberFormatter alloc] init];
    [formatter setNumberStyle:NSNumberFormatterSpellOutStyle];

    NSString *spelledOut = [formatter stringFromNumber:[NSNumber numberWithInt:increment]];
    
    // This sets the title for the navigation bar, and for the tab bar. The tab bar
    // controller doesn't look at this view controller's tab bar item, though; it looks
    // at our parent navigation controller's tab bar item. However, our parent navigation
    // controller "inherits" its tab bar item from us, so it gets this title.
    self.title = [spelledOut capitalizedString];
    
    // This overrides our navigation bar title.
    self.navigationItem.title = [NSString stringWithFormat:@"Increment by %@", spelledOut];
  }
  return self;
}

#pragma mark Table view methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 20;
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
  NSString *CellIdentifier = @"Cell";

  UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
  if (cell == nil) {
    cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
  }

  NSNumber *number = [NSNumber numberWithInt:(indexPath.row * increment)];
  cell.text = [formatter stringFromNumber:number];

  return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
  DetailViewController *details = [[DetailViewController alloc] initWithIncrement:increment
                                                                            index:indexPath.row];
  [self.navigationController pushViewController:details animated:YES];
  [details release];
}


- (void)dealloc {
  [formatter release];
  [super dealloc];
}


@end

