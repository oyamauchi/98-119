//
//  ClickCountAppDelegate.m
//  ClickCount
//
//  Created by Owen Yamauchi on 1/13/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "ClickCountAppDelegate.h"


@implementation ClickCountAppDelegate

@synthesize window;
@synthesize progressView;

- (void)applicationDidFinishLaunching:(UIApplication *)application {
  [progressView setProgress:0.0];
  [window makeKeyAndVisible];
}


- (IBAction)buttonPressed:(id)sender {
  [progressView setProgress:[progressView progress] + 0.1];
}


- (void)dealloc {
  [window release];
  [progressView release];
  [super dealloc];
}


@end
