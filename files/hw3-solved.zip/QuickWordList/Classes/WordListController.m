//
//  WordListController.m
//  QuickWordList
//
//  Created by Owen Yamauchi on 2/3/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "WordListController.h"

#define kNEW_SECTION 0
#define kNUMBERS_SECTION 1

@implementation WordListController


- (id)initWithStyle:(UITableViewStyle)style {
  if (self = [super initWithStyle:style]) {
    wordList = [[NSMutableArray alloc] init];
    
    int i;
    NSNumberFormatter *f = [[NSNumberFormatter alloc] init];
    [f setNumberStyle:NSNumberFormatterSpellOutStyle];
    for (i = 0; i < 200; i += 10) {
      [wordList addObject:[f stringFromNumber:[NSNumber numberWithInt:i]]];
    }
    [f release];
  }
  return self;
}


- (void)viewDidLoad {
  [super viewDidLoad];
  self.navigationItem.rightBarButtonItem = self.editButtonItem;
}


/*
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}
*/
/*
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}
*/
/*
- (void)viewWillDisappear:(BOOL)animated {
	[super viewWillDisappear:animated];
}
*/
/*
- (void)viewDidDisappear:(BOOL)animated {
	[super viewDidDisappear:animated];
}
*/

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
}

#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
  return (section == kNEW_SECTION ? 1 : [wordList count]);
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
  NSString *CellIdentifier = @"Cell";

  UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
  if (cell == nil) {
    cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
  }

  if (indexPath.section == kNUMBERS_SECTION) {
    cell.text = [wordList objectAtIndex:indexPath.row];
  } else {
    cell.text = @"New section";
  }

  return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
  // Navigation logic may go here.
}

// This makes the header appear
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
  return (section == kNEW_SECTION ? nil : @"Numbers");
}



// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
  return indexPath.section == kNUMBERS_SECTION;
}



// Override to support editing the table view.
-   (void)tableView:(UITableView *)tableView
 commitEditingStyle:(UITableViewCellEditingStyle)editingStyle
  forRowAtIndexPath:(NSIndexPath *)indexPath {
    
  // The other case, UITableViewCellEditingStyleInsert, won't happen in this app
  if (editingStyle == UITableViewCellEditingStyleDelete) {
    [wordList removeObjectAtIndex:indexPath.row];
    [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:YES];
  }
}



// Override to support rearranging the table view. (Commented out for HW3)
/*
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
  NSString *temp = [[wordList objectAtIndex:fromIndexPath.row] retain];
  [wordList removeObjectAtIndex:fromIndexPath.row];
  [wordList insertObject:temp atIndex:toIndexPath.row];
  [temp release];
}
*/


/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


- (void)dealloc {
  [wordList release];
  [super dealloc];
}


@end

