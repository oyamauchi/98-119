//
//  ListController.m
//  LanguageList
//
//  Created by Owen Yamauchi on 2/17/09.
//  Copyright 2009 Owen Yamauchi. All rights reserved.
//

#import "ListController.h"
#import "WebViewController.h"

@implementation ListController


- (id)initWithStyle:(UITableViewStyle)style {
	if (self = [super initWithStyle:style]) {
    NSString *preference =
      [[NSUserDefaults standardUserDefaults] objectForKey:@"language_family_preference"];
    
    if (preference == nil) {
      // Use Germanic if there's no preference set yet. Unfortunately you have to
      // enforce a default in code separately from the default value in the settings
      // plist: the one from the settings plist doesn't get stored in user defaults
      // until the Settings app is launched.
      preference = @"germanic";
    }
    
    // At the end of days, I will be judged very harshly for putting all these
    // non-ASCII characters in a source code file.
    if (preference == nil || [preference isEqualToString:@"germanic"]) {
      englishNames = [[NSMutableArray alloc] initWithObjects:@"Afrikaans", @"Danish",
                      @"Dutch", @"English", @"Faeroese", @"Frisian", @"German", @"Icelandic",
                      @"Norwegian", @"Swedish", @"Yiddish", nil];
      nativeNames = [[NSMutableArray alloc] initWithObjects:@"Afrikaans", @"Dansk",
                     @"Nederlands", @"English", @"føroyskt", @"Frysk", @"Deutsch", @"íslenska",
                     @"Norsk", @"Svenska", @"yidish", nil];
    } else if ([preference isEqualToString:@"italic"]) {
      englishNames = [[NSMutableArray alloc] initWithObjects:@"French", @"Italian",
                      @"Romanian", @"Romansh", @"Spanish", nil];
      nativeNames = [[NSMutableArray alloc] initWithObjects:@"Français", @"Italiano",
                     @"Română", @"Rumantsch", @"Español", nil];
    } else if ([preference isEqualToString:@"baltoslavic"]) {
      englishNames = [[NSMutableArray alloc] initWithObjects:@"Belarusian", @"Bulgarian",
                      @"Polish", @"Russian", @"Ukrainian", nil];
      nativeNames = [[NSMutableArray alloc] initWithObjects:@"Беларуская", @"Български",
                     @"Polski", @"Русский", @"Українська", nil];
    } else {
      englishNames = [[NSMutableArray alloc] initWithObjects:@"Breton", @"Irish Gaelic",
                      @"Scots Gaelic", @"Welsh", nil];
      nativeNames = [[NSMutableArray alloc] initWithObjects:@"Brezhoneg", @"Gaeilge",
                     @"Gàidhlig", @"Cymraeg", nil];
    }

    NSString *familyName = [preference capitalizedString];
		self.title = [NSString stringWithFormat:@"%@ languages", familyName];

		UIBarButtonItem *backItem = [[UIBarButtonItem alloc] initWithTitle:familyName
																																 style:UIBarButtonItemStyleBordered
																																target:nil
																																action:nil];
		self.navigationItem.backBarButtonItem = backItem;
		[backItem release];
	}
	return self;
}


// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	// Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	return 1;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	// Hopefully [englishNames count] and [nativeNames count] are the same
	return [englishNames count];
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	static NSString *CellIdentifier = @"Cell";
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
		cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	}
	
	NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
	BOOL useEnglish = [ud boolForKey:@"english_preference"];
	if (useEnglish) {
		cell.text = [englishNames objectAtIndex:indexPath.row];
	} else {
		cell.text = [nativeNames objectAtIndex:indexPath.row];
	}

	return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	NSString *language = [englishNames objectAtIndex:indexPath.row];
	WebViewController *wvc = [[WebViewController alloc] initWithLanguageName:language];
	[self.navigationController pushViewController:wvc animated:YES];
	[wvc release];
}


- (void)dealloc {
	[englishNames release];
	[nativeNames release];
	[super dealloc];
}


@end

