//
//  WebViewController.m
//  LanguageList
//
//  Created by Owen Yamauchi on 2/17/09.
//  Copyright 2009 Owen Yamauchi. All rights reserved.
//

#import "WebViewController.h"


@implementation WebViewController

- (id)initWithLanguageName:(NSString *)lang
{
	if (!(self = [super initWithNibName:nil bundle:nil])) {
		return nil;
	}
	languageName = [lang retain];
	self.title = languageName;
	
	UIActivityIndicatorView *spinnerView =
		[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
	spinner = [[UIBarButtonItem alloc] initWithCustomView:spinnerView];
	[spinnerView startAnimating];
	[spinnerView release];

	return self;
}


// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
  // Return YES for supported orientations
	return YES;
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	[self.navigationController
		setNavigationBarHidden:(self.interfaceOrientation != UIInterfaceOrientationPortrait)
								  animated:YES];
}


// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
	webView = [[UIWebView alloc] initWithFrame:CGRectZero];
	webView.delegate = self;
	webView.scalesPageToFit = YES;
	webView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	self.view = webView;
	[webView release];

	self.navigationItem.rightBarButtonItem = spinner;
}

- (void)webViewDidFinishLoad:(UIWebView *)wv
{
	self.navigationItem.rightBarButtonItem = nil;
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	[super viewDidLoad];
	
	NSString *urlStr =
		[NSString stringWithFormat:@"http://en.wikipedia.org/wiki/%@_language", languageName];
	NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:urlStr]];
	[webView loadRequest:request];
}

- (void)dealloc {
	webView.delegate = nil;
	[spinner release];
	[languageName release];
	[super dealloc];
}


@end
