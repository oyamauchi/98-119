//
//  ListController.m
//  SpeakersList
//
//  Created by Owen Yamauchi on 3/17/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "ListController.h"
#import "TitleDetailCell.h"

@implementation ListController

- (id)initWithStyle:(UITableViewStyle)style {
  if (self = [super initWithStyle:style]) {
    languages = [[NSMutableArray alloc] init];
    speakerCounts = [[NSMutableArray alloc] init];

    NSURL *url =
      [NSURL URLWithString:@"http://www.contrib.andrew.cmu.edu/~ody/files/ethnologue.txt"];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    NSURLConnection *connection = [NSURLConnection connectionWithRequest:request
                                                                delegate:self];
    loadedData = [[NSMutableData alloc] init];
    [connection start];
  }
  return self;
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
  [loadedData appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
  NSString *content = [[NSString alloc] initWithData:loadedData
                                            encoding:NSUTF8StringEncoding];
  
  NSArray *lines = [content componentsSeparatedByString:@"\n"];
  for (NSString *line in lines) {
    NSArray *fields = [line componentsSeparatedByString:@","];
    if ([fields count] == 2) {
      [languages addObject:[fields objectAtIndex:0]];
      [speakerCounts addObject:[fields objectAtIndex:1]];
    }
  }
  
  [content release];
  [loadedData setLength:0];
  [(UITableView *)self.view reloadData];
}

#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [languages count];
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
  static NSString *CellIdentifier = @"Cell";

  // Change to TitleDetailCell
  TitleDetailCell *cell = (TitleDetailCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
  if (cell == nil) {
    // Change to TitleDetailCell
    cell = [[[TitleDetailCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
  }

	NSString *language = [languages objectAtIndex:indexPath.row];
  [[cell titleLabel] setText:language];
  [[cell paritySwitch] setOn:([language length] % 2 == 1)];

  return cell;
}


- (void)dealloc {
  [languages release];
  [speakerCounts release];
  [loadedData release];
  [super dealloc];
}


@end

