//
//  SpeakersListAppDelegate.h
//  SpeakersList
//
//  Created by Owen Yamauchi on 3/17/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ListController.h"

@interface SpeakersListAppDelegate : NSObject <UIApplicationDelegate> {
  IBOutlet UIWindow *window;
  ListController *controller;
}


@end

