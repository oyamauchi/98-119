//
//  TitleDetailCell.m
//  SpeakersList
//
//  Created by Owen Yamauchi on 3/17/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "TitleDetailCell.h"


@implementation TitleDetailCell

- (id)initWithFrame:(CGRect)frame reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithFrame:frame reuseIdentifier:reuseIdentifier]) {
      titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
      titleLabel.font = [UIFont boldSystemFontOfSize:[UIFont labelFontSize]];
      titleLabel.backgroundColor = [UIColor clearColor];

			paritySwitch = [[UISwitch alloc] initWithFrame:CGRectZero];
      
      [[self contentView] addSubview:titleLabel];
      [[self contentView] addSubview:paritySwitch];
    }
    return self;
}

- (UILabel *)titleLabel
{
  return titleLabel;
}

- (UISwitch *)paritySwitch
{
  return paritySwitch;
}

- (void)layoutSubviews
{
  CGRect rect = self.contentView.bounds;
  rect.origin.x += 20;
  rect.size.width -= 40;
  titleLabel.frame = rect;
	
	rect.origin.x = self.contentView.bounds.size.width - 20 - paritySwitch.frame.size.width;
	rect.origin.y = (self.contentView.bounds.size.height - paritySwitch.frame.size.height) / 2.0;
	rect.size = paritySwitch.frame.size;
  paritySwitch.frame = rect;
}

- (void)dealloc {
  [titleLabel release];
  [paritySwitch release];
  [super dealloc];
}


@end
