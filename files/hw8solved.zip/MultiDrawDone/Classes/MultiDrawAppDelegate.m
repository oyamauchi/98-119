//
//  MultiDrawAppDelegate.m
//  MultiDraw
//
//  Created by Owen Yamauchi on 3/24/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "MultiDrawAppDelegate.h"
#import "MultiDrawView.h"

@implementation MultiDrawAppDelegate

@synthesize window;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
  MultiDrawView *v = [[MultiDrawView alloc] initWithFrame:[window bounds]];
  [window addSubview:v];
  [v release];

  // Override point for customization after application launch
  [window makeKeyAndVisible];
}


- (void)dealloc {
    [window release];
    [super dealloc];
}


@end
