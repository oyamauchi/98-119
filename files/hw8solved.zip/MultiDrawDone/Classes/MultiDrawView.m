//
//  MultiDrawView.m
//  MultiDraw
//
//  Created by Owen Yamauchi on 3/24/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "MultiDrawView.h"


@implementation MultiDrawView


- (id)initWithFrame:(CGRect)frame {
  if (self = [super initWithFrame:frame]) {
    currentTouches = [[NSMutableDictionary alloc] init];
    
    storedDrawing = CGBitmapContextCreate(NULL,
                                          self.bounds.size.width,
                                          self.bounds.size.height,
                                          8,
                                          4 * self.bounds.size.width,
                                          CGColorSpaceCreateDeviceRGB(),
                                          kCGImageAlphaNoneSkipLast);
    CGContextSetRGBFillColor(storedDrawing, 1.0, 1.0, 1.0, 1.0);
    CGContextFillRect(storedDrawing, self.bounds);
    self.multipleTouchEnabled = YES;
  }
  return self;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
  for (UITouch *t in touches) {
    CGMutablePathRef path = CGPathCreateMutable();
    CGPoint location = [t locationInView:self];
    CGPathMoveToPoint(path, NULL, location.x, location.y);
    
    NSValue *key = [NSValue valueWithPointer:t];
    NSValue *value = [NSValue valueWithPointer:path];
    [currentTouches setObject:value forKey:key];
  }
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
  for (UITouch *t in touches) {
    CGPoint location = [t locationInView:self];
    NSValue *key = [NSValue valueWithPointer:t];
    CGMutablePathRef path = (CGMutablePathRef)[[currentTouches objectForKey:key] pointerValue];
    CGPathAddLineToPoint(path, NULL, location.x, location.y);
  }
  [self setNeedsDisplay];
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	if ([[event allTouches] count] == 1 && [[[event allTouches] anyObject] tapCount] == 2) {
		CGContextSetRGBStrokeColor(storedDrawing, 1.0, 1.0, 1.0, 1.0);
		CGContextFillRect(storedDrawing, self.bounds);
		[self setNeedsDisplay];
		return;
	}

  for (UITouch *t in touches) {
    NSValue *key = [NSValue valueWithPointer:t];
    CGMutablePathRef path = (CGMutablePathRef)[[currentTouches objectForKey:key] pointerValue];
    CGContextSetRGBStrokeColor(storedDrawing, 1.0, 0.0, 0.0, 1.0);
    CGContextAddPath(storedDrawing, path);
    CGContextStrokePath(storedDrawing);
    
    CGPathRelease(path);
    [currentTouches removeObjectForKey:key];
  }
  [self setNeedsDisplay];
}


- (void)drawRect:(CGRect)rect {
  CGContextRef context = UIGraphicsGetCurrentContext();

  CGImageRef image = CGBitmapContextCreateImage(storedDrawing);
  CGContextDrawImage(context, self.bounds, image);
	CGImageRelease(image);

  for (NSValue *key in currentTouches) {
    CGMutablePathRef path = (CGMutablePathRef)[[currentTouches objectForKey:key] pointerValue];
    CGContextSetRGBStrokeColor(context, 1.0, 0.0, 0.0, 1.0);
    CGContextAddPath(context, path);
    CGContextStrokePath(context);    
  }
}


- (void)dealloc {
  [currentTouches release];
  CGContextRelease(storedDrawing);
  [super dealloc];
}


@end
