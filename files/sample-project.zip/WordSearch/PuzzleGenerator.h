//
//  PuzzleGenerator.h
//
//  Created by Owen Yamauchi for 98-119, S09.
//  For use in WordSearch.
//

#import <Cocoa/Cocoa.h>

#define kGENERATOR_PUZZLE_KEY    @"Puzzle"
#define kGENERATOR_SOLUTIONS_KEY @"Solutions"

/*
 * This is a class that represents the location of a word within a puzzle. The origin
 * is in the top-left corner of the puzzle (i.e. the top-left letter is (0,0)). The
 * coordinates are of the first and last letters in the word.
 */
@interface WordPosition : NSObject
{
  int startX, startY;
  int endX, endY;
}
@property(assign) int startX;
@property(assign) int startY;
@property(assign) int endX;
@property(assign) int endY;
@end


@interface PuzzleGenerator : NSObject
{
  int width;
  int height;
}
@property(assign) int width;
@property(assign) int height;

- (id)initWithWidth:(int)pWidth height:(int)pHeight;

/*
 * Generates a word-search puzzle and returns it and its solution.
 *
 * Pass it an array of words to put in the puzzle. You can pass in words in any case,
 * but the puzzle will be in all uppercase.
 *
 * - The puzzle itself is returned as an NSArray. Each element in the array is an
 *   NSString representing a row. So, for example, to print out a puzzle on a text
 *   console, you would just print the first element of the array, followed by a
 *   newline, then the second element, and so on.
 * - The solutions are returned as an NSDictionary. The keys are the words, and the
 *   values are WordPosition objects, which contain the coordinates of the first and
 *   last characters in the word (see the declaration of WordPosition above).
 *
 * The randomFill parameter determines what to do with empty space in the puzzle. If
 * YES is passed, the empty space is filled with pseudo-random letters. If NO is
 * passed, the space is filled with space characters so the answers are visible.
 *
 * The puzzle is returned under the key kGENERATOR_PUZZLE_KEY, and the solutions are
 * returned under the key kGENERATOR_SOLUTIONS_KEY.
 *
 * In some cases, it may be impossible to generate a puzzle with the parameters you
 * specify (or this algorithm just isn't good enough). In this case, nil is returned.
 */
- (NSDictionary *)puzzleWithWords:(NSArray *)words randomFill:(BOOL)randomFill;

@end
