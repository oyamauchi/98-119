//
//  PuzzleGenerator.m
//
//  Created by Owen Yamauchi for 98-119, S09.
//  For use in WordSearch.
//

/*
 * The algorithm this code uses to generate word search puzzles is very simple. For each
 * word, it performs the following procedure:
 * - Choose a random location for the start of the word (ensuring that this is not a
 *   location that has been tried before)
 * - Try each of the eight possible directions in random order. If a direction results
 *   in a fit (i.e. the word placed with that starting location and direction does not
 *   conflict with any words already there, and does not go beyond the boundaries of
 *   the puzzle), then the word is placed and we are done with the word.
 * - If the word doesn't fit in any of the eight directions, try another starting
 *   location. If we have tried 75% of the locations in the puzzle as starting locations,
 *   give up: we fail to place the word.
 *
 * If a word fails to be placed, the entire puzzle is scrapped and we start over from
 * scratch. If 30 attempts fail, we give up altogether and declare the puzzle impossible.
 *
 * This algorithm is often suboptimal. The resulting puzzles often don't have as much
 * overlap between words as one might like (overlap is allowed, but turns out to be rare
 * in generated puzzles). It is also entirely possible that a list of words might have
 * a possible puzzle, but this algorithm will not find it.
 *
 * Before attempting to create a puzzle, we ensure that no word is longer than both
 * dimensions of the puzzle - if that is true, it's impossible to form a puzzle.
 */

#import "PuzzleGenerator.h"

/* Either of the following two numbers could be increased to increase the "perseverance"
 * of the algorithm - how hard it tries to create a puzzle. I doubt that it would help
 * all that much to increase them, though.
 */
#define kMAX_PUZZLE_ATTEMPTS 30
#define kMAX_WORD_ATTEMPTS_MULTIPLIER 0.75
#define kSHUFFLE_AMOUNT 20

static NSMutableArray *directions = nil;
typedef enum {
  kDirectionUp,
  kDirectionUpRight,
  kDirectionRight,
  kDirectionDownRight,
  kDirectionDown,
  kDirectionDownLeft,
  kDirectionLeft,
  kDirectionUpLeft
} Direction;

@interface Pair : NSObject
{
  int x, y;
}
@property(assign) int x;
@property(assign) int y;
+ (Pair *)pairWithX:(int)inX y:(int)inY;
@end

@implementation Pair
@synthesize x;
@synthesize y;
+ (Pair *)pairWithX:(int)inX y:(int)inY
{
  Pair *p = [[self alloc] init];
  p.x = inX;
  p.y = inY;
  return [p autorelease];
}
- (BOOL)isEqual:(id)other
{
  if (![other isKindOfClass:[Pair class]]) {
    return NO;
  }
  return ([other x] == x && [other y] == y);
}
- (unsigned int)hash
{
  return x + y;
}
@end


@implementation WordPosition
@synthesize startX;
@synthesize startY;
@synthesize endX;
@synthesize endY;
- (NSString *)description
{
  return [NSString stringWithFormat:@"((%i, %i), (%i, %i))", startX, startY, endX, endY];
}
@end


@implementation PuzzleGenerator

@synthesize width;
@synthesize height;

+ (void)initialize
{
  int i;
  directions = [[NSMutableArray alloc] init];
  for (i = 0; i < 8; i++) {
    [directions addObject:[NSNumber numberWithInt:i]];
  }
}

- (id)initWithWidth:(int)pWidth height:(int)pHeight
{
  if (!(self = [super init])) {
    return nil;
  }
  width = pWidth;
  height = pHeight;
  return self;
}

- (char **)allocatePuzzle
{
  char **puzzle = calloc(width, sizeof(char *));
  int i;
  
  for (i = 0; i < width; i++) {
    puzzle[i] = calloc(height, sizeof(char));
  }
  
  return puzzle;
}

- (void)freePuzzle:(char **)p
{
  int i;
  
  for (i = 0; i < width; i++) {
    free(p[i]);
  }
  
  free(p);
}

/*
 * Shuffles the array of directions that is iterated over in order when trying to
 * place a word in the puzzle.
 */
- (void)shuffleDirections
{
  int i;
  
  for (i = 0; i < kSHUFFLE_AMOUNT; i++) {
    int a = random() % 8;
    int b = random() % 8;
    [directions exchangeObjectAtIndex:a withObjectAtIndex:b];
  }
}

/*
 * Given a starting position, word length and direction, returns the location of
 * the end of the word. Does no bounds checking. The values are returned by
 * reference in outX and outY (both of which must be valid pointers).
 */
- (void)endsForStartX:(int)startX
               startY:(int)startY
                 outX:(int *)outX
                 outY:(int *)outY
            direction:(Direction)dir
               length:(int)length
{
  length--;
  switch (dir) {
    case kDirectionUp:
      *outY = startY - length; *outX = startX; break;
    case kDirectionUpRight:
      *outY = startY - length; *outX = startX + length; break;
    case kDirectionRight:
      *outY = startY; *outX = startX + length; break;
    case kDirectionDownRight:
      *outY = startY + length; *outX = startX + length; break;
    case kDirectionDown:
      *outY = startY + length; *outX = startX; break;
    case kDirectionDownLeft:
      *outY = startY + length; *outX = startX - length; break;
    case kDirectionLeft:
      *outY = startY; *outX = startX - length; break;
    case kDirectionUpLeft:
      *outY = startY - length; *outX = startX - length; break;
  }
}

/*
 * If modify is NO, the method just tests to see if the given word fits in the
 * puzzle at the given place. If modify is YES, the method actually modifies the
 * puzzle to have the word there (without testing - it will just overwrite any
 * letters already there).
 */
- (BOOL)fit:(NSString *)theWord
   inPuzzle:(char **)puzzle
  direction:(Direction)dir
          x:(int)x
          y:(int)y
     modify:(BOOL)modify
{
  const char *word = [[theWord uppercaseString] UTF8String];
  int length = [theWord length];
  int i;
  
  for (i = 0; i < length; i++) {
    if (modify) {
      puzzle[x][y] = *word;
    } else {
      if (puzzle[x][y] != '\0' && puzzle[x][y] != *word) {
        return NO;
      }
    }
    word++;
    switch (dir) {
      case kDirectionUp:
        y--; break;
      case kDirectionUpRight:
        y--; x++; break;
      case kDirectionRight:
        x++; break;
      case kDirectionDownRight:
        x++; y++; break;
      case kDirectionDown:
        y++; break;
      case kDirectionDownLeft:
        y++; x--; break;
      case kDirectionLeft:
        x--; break;
      case kDirectionUpLeft:
        x--; y--; break;
    }
  }
  return YES;
}

/*
 * Try to find a place for the given word in the given puzzle. Returns the place of
 * the word if it could be placed, nil otherwise. It will modify the puzzle if the
 * word fits.
 */
- (WordPosition *)placeWord:(NSString *)word inPuzzle:(char **)puzzle
{
  NSMutableSet *triedStarts = [NSMutableSet set];
  int length = [word length];
  int cutoff = kMAX_WORD_ATTEMPTS_MULTIPLIER * width * height;

  while ([triedStarts count] < cutoff) {
    int startX = random() % width;
    int startY = random() % height;
    Pair *start = [Pair pairWithX:startX y:startY];
    
    if ([triedStarts containsObject:start]) {
      continue;
    }
    [triedStarts addObject:start];
    
    [self shuffleDirections];
    for (NSNumber *directionNum in directions) {
      int endX = -1, endY = -1;
      Direction dir = [directionNum intValue];
      [self endsForStartX:startX
                   startY:startY
                     outX:&endX
                     outY:&endY
                direction:dir
                   length:length];
      BOOL ok = (endX >= 0 && endX < width && endY >= 0 && endY < height);
      ok = ok && [self fit:word
                  inPuzzle:puzzle
                 direction:dir
                         x:startX 
                         y:startY
                    modify:NO];
      if (ok) {
        WordPosition *solution = [[WordPosition alloc] init];
        solution.startX = startX;
        solution.startY = startY;
        solution.endX = endX;
        solution.endY = endY;
        [self fit:word inPuzzle:puzzle direction:dir x:startX y:startY modify:YES];
        return [solution autorelease];
      }
    }
  }
  return nil;
}

/*
 * Fills in the blank spots in a puzzle with pseudo-random letters.
 */
- (void)fillRemaining:(char **)puzzle fromWords:(NSArray *)words randomFill:(BOOL)randomFill
{
  int i, j;
  NSMutableString *allWords = [NSMutableString string];
  
  /* Nudge the distribution of filler letters towards that of the target words,
   * but allow any letter to appear.
   */
  for (NSString *word in words) {
    [allWords appendString:[word uppercaseString]];
  }
  [allWords appendString:@"ABCDEFGHIJKLMNOPQRSTUVWXYZ"];
  
  for (i = 0; i < width; i++) {
    for (j = 0; j < height; j++) {
      if (puzzle[i][j] == '\0') {
        puzzle[i][j] =
          (randomFill ? [allWords characterAtIndex:(random() % [allWords length])] : ' ');
      }
    }
  }
}

/*
 * Converts the 2D char array into an NSArray of NSStrings, for external use.
 */
- (NSArray *)convertToArray:(char **)puzzle
{
  NSMutableArray *result = [NSMutableArray array];
  int i, j;
  
  for (i = 0; i < height; i++) {
    char *buf = calloc(width + 1, sizeof(char));
    for (j = 0; j < width; j++) {
      buf[j] = puzzle[j][i];
    }
    [result addObject:[NSString stringWithCString:buf encoding:NSUTF8StringEncoding]];
    free(buf);
  }
  
  return result;
}

/*
 * Try to create a puzzle with the given words. Modifies the passed puzzle to put the
 * words in, and returns an NSDictionary of solutions (suitable for passing to the
 * PuzzleGenerator client). If it can't find a place for a word, returns nil.
 */
- (NSDictionary *)tryCreateWithWords:(NSArray *)words puzzle:(char **)puzzle
{
  NSMutableDictionary *result = [NSMutableDictionary dictionary];
  for (NSString *word in words) {
    WordPosition *place = [self placeWord:word inPuzzle:puzzle];
    if (!place) {
      return nil;
    }
    [result setObject:place forKey:word];
  }
  return result;
}

- (NSDictionary *)puzzleWithWords:(NSArray *)words randomFill:(BOOL)randomFill
{
  if (width == 0 || height == 0) {
    return nil;
  }
  
  char **puzzle = [self allocatePuzzle];
  srandom(clock());
  
  /* Quick sanity check: make sure each word will fit in grid */
  for (NSString *word in words) {
    if ([word length] > width && [word length] > height) {
      [self freePuzzle:puzzle];
      return nil;
    }
  }
  
  int attempts = 0;
  NSDictionary *solution = nil;
  while (attempts < kMAX_PUZZLE_ATTEMPTS) {
    solution = [self tryCreateWithWords:words puzzle:puzzle];
    if (solution) {
      break;
    } else {
      attempts++;
      [self freePuzzle:puzzle];
      puzzle = [self allocatePuzzle];
    }
  }
  
  if (!solution) {
    return nil;
  }

  [self fillRemaining:puzzle fromWords:words randomFill:randomFill];
  
  NSArray *puzzleArray = [self convertToArray:puzzle];
  
  [self freePuzzle:puzzle];
  return [NSDictionary dictionaryWithObjectsAndKeys:puzzleArray, kGENERATOR_PUZZLE_KEY,
          solution, kGENERATOR_SOLUTIONS_KEY, nil];
}

@end
