#import <Foundation/Foundation.h>
#import "PuzzleGenerator.h"

void printPuzzle(NSArray *puzzle) {
  for (NSString *row in puzzle) {
    printf("%s\n", [row UTF8String]);
  }
}

int main (int argc, const char * argv[]) {
  /* Don't worry about what this line does - but don't remove it */
  NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
  
  /* Code you care about starts here */
  PuzzleGenerator *pg = [[PuzzleGenerator alloc] initWithWidth:15 height:15];
  
  /* For the curious, these words are the major extant members of the
   * Germanic subfamily of the Indo-European language family.
   */
  NSMutableArray *words = [NSMutableArray array];
  [words addObject:@"afrikaans"];
  [words addObject:@"danish"];
  [words addObject:@"dutch"];
  [words addObject:@"english"];
  [words addObject:@"faeroese"];
  [words addObject:@"frisian"];
  [words addObject:@"german"];
  [words addObject:@"gothic"];
  [words addObject:@"icelandic"];
  [words addObject:@"norwegian"];
  [words addObject:@"swedish"];
  [words addObject:@"yiddish"];
  
  NSDictionary *puzzle = [pg puzzleWithWords:words randomFill:NO];
  
  if (puzzle) {
    printPuzzle([puzzle objectForKey:kGENERATOR_PUZZLE_KEY]);
    NSLog(@"%@", [puzzle objectForKey:kGENERATOR_SOLUTIONS_KEY]);
  } else {
    printf("Failed to create a puzzle\n");
  }
  
  [pg release];
  
  /* Don't mind this line but don't remove it */
  [pool drain];
  return 0;
}
